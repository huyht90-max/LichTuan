# Lịch Tuần

App lịch Android giao diện tuần kiểu Windows Phone. Đọc và ghi thẳng vào **lịch hệ thống** (Google Calendar, Samsung Calendar...), kèm widget **live tile** để đặt vào launcher.

## Tính năng

- Xem theo tuần: 7 ngày xếp 2 cột, ô cuối là lịch tháng nhỏ (tô sáng tuần đang xem, ngày hôm nay màu nhấn).
- Vuốt trái/phải để đổi tuần. Chạm tiêu đề tháng để chọn ngày bất kỳ. Chạm ngày trong lịch nhỏ để nhảy tới tuần đó.
- Chạm một ngày để xem sự kiện, thêm, sửa, xóa. Sự kiện được ghi vào lịch của máy nên đồng bộ với Google Calendar và hiện ở mọi app lịch khác.
- Sự kiện lặp lại hoặc kéo dài nhiều ngày sẽ mở bằng app Lịch của máy để tránh làm hỏng dữ liệu.
- Nút ☰: chọn lịch nào được hiển thị. Nút •••: màu nhấn (20 màu Windows Phone), bật/tắt ngày lễ Việt Nam có sẵn.
- Widget "Lịch Tuần (tile)": hiện sự kiện sắp tới và ngày hôm nay, nền theo màu nhấn, tự cập nhật khi lịch thay đổi.

## Cách 1: Build APK bằng GitHub (không cần cài gì lên máy tính)

1. Tạo tài khoản tại github.com (nếu chưa có), bấm **New repository**, đặt tên `LichTuan`, chọn **Private**, bấm Create.
2. Giải nén file zip. Trong repo vừa tạo bấm **uploading an existing file**, kéo **toàn bộ nội dung** thư mục `LichTuan` vào (không kéo chính thư mục), bấm **Commit changes**.
3. Thư mục `.github` là thư mục ẩn nên có thể không được tải lên. Kiểm tra: nếu repo chưa có `.github/workflows/build.yml` thì bấm **Add file → Create new file**, gõ tên `.github/workflows/build.yml`, dán nội dung file đó vào, bấm Commit.
4. Vào tab **Actions**, đợi lượt build có dấu tích xanh (khoảng 3–5 phút). Bấm vào lượt build, kéo xuống mục **Artifacts**, tải `LichTuan-apk` (file zip chứa `app-debug.apk`).
5. Chép APK sang điện thoại, mở để cài (cho phép "cài ứng dụng không rõ nguồn gốc" khi được hỏi).

## Cách 2: Android Studio

Mở thư mục `LichTuan` bằng Android Studio, đợi đồng bộ Gradle, cắm điện thoại và bấm **Run**, hoặc **Build → Build APK(s)**.

## Đưa lên launcher kiểu Windows Phone

1. Mở app một lần và cấp quyền **Lịch**.
2. Trong launcher, thêm widget **Lịch Tuần (tile)** vào một ô tile (với Square Home: nhấn giữ ô tile → chọn kiểu widget; tùy launcher có thể khác).
3. Chạm vào tile sẽ mở app Lịch Tuần.

Muốn tile trùng màu với các tile khác, vào ••• → màu nhấn và chọn ô đầu tiên (xanh Windows 10, #0078D7).
