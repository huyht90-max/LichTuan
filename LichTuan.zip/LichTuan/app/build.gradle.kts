plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "vn.lichtuan"
    compileSdk = 34

    // Số lần build trên GitHub, để mỗi bản mới có số phiên bản lớn hơn bản cũ.
    val build = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()

    defaultConfig {
        applicationId = "vn.lichtuan"
        minSdk = 26
        targetSdk = 34
        versionCode = build
        versionName = "1.$build"
    }

    // Khóa ký cố định: mọi bản build đều cùng chữ ký nên cài đè được, không phải gỡ app.
    signingConfigs {
        create("shared") {
            storeFile = file("lichtuan.keystore")
            storePassword = "lichtuan"
            keyAlias = "lichtuan"
            keyPassword = "lichtuan"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("shared")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("shared")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
