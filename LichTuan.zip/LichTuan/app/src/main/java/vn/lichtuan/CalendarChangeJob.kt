package vn.lichtuan

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.provider.CalendarContract

/** Chạy mỗi khi lịch hệ thống thay đổi (từ bất kỳ app nào) để làm mới live tile. */
class CalendarChangeJob : JobService() {

    override fun onStartJob(params: JobParameters): Boolean {
        WeekTileWidget.updateAll(applicationContext)
        return false
    }

    override fun onStopJob(params: JobParameters): Boolean = false

    companion object {
        private const val ID = 4242

        fun schedule(ctx: Context) {
            val js = ctx.getSystemService(JobScheduler::class.java) ?: return
            val info = JobInfo.Builder(ID, ComponentName(ctx, CalendarChangeJob::class.java))
                .addTriggerContentUri(
                    JobInfo.TriggerContentUri(
                        CalendarContract.CONTENT_URI,
                        JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS
                    )
                )
                .setTriggerContentUpdateDelay(2_000)
                .setTriggerContentMaxDelay(10_000)
                .build()
            try {
                js.schedule(info)
            } catch (e: Exception) {
            }
        }

        fun cancel(ctx: Context) {
            ctx.getSystemService(JobScheduler::class.java)?.cancel(ID)
        }
    }
}
