package vn.lichtuan

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.CalendarContract
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset

class MainActivity : Activity() {

    private companion object {
        const val REQ_PERM = 7
        const val DAY = 86_400_000L
        const val AGENDA_DAYS = 60L
        val PANEL_BG = 0xFF8A939B.toInt()
    }

    private lateinit var titleView: TextView
    private lateinit var moreBtn: TextView
    private lateinit var content: SwipeFrame

    // Tuần
    private lateinit var weekGrid: WeekGridLayout
    private lateinit var mini: MiniMonthView
    private val cells = ArrayList<DayCell>()

    // Ngày
    private lateinit var dayRoot: LinearLayout
    private lateinit var dayTitle: TextView
    private lateinit var allDayBox: LinearLayout
    private lateinit var dayScroll: ScrollView
    private lateinit var timeline: DayTimelineView
    private var scrolledDay: LocalDate? = null

    // Tháng, năm, lịch công tác
    private lateinit var monthView: MonthGridView
    private lateinit var yearView: YearView
    private lateinit var agendaScroll: ScrollView
    private lateinit var agendaList: LinearLayout

    // Menu chọn kiểu xem
    private lateinit var overlay: FrameLayout
    private lateinit var sheet: LinearLayout
    private val modeLabels = HashMap<Mode, TextView>()

    private var mode = Mode.WEEK
    private var anchor: LocalDate = LocalDate.now()
    private val weekStart: LocalDate get() = mondayOf(anchor)
    private var shown: Map<LocalDate, List<Ev>> = emptyMap()
    private var accent = 0

    // ---------------------------------------------------------------- vòng đời

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        accent = Prefs.accent(this)
        mode = Prefs.mode(this)
        savedInstanceState?.getString("anchor")?.let { anchor = LocalDate.parse(it) }
        setContentView(buildUi())
        if (!Repo.canWrite(this)) askPerm()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("anchor", anchor.toString())
    }

    override fun onResume() {
        super.onResume()
        reload(0)
        WeekTileWidget.updateAll(this)
    }

    @Deprecated("Vẫn dùng được với targetSdk 34")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (overlay.visibility == View.VISIBLE) hidePanel() else super.onBackPressed()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            if (!Repo.hasPerm(this)) toast("Chưa có quyền lịch nên chỉ hiện ngày lễ")
            reload(0)
            WeekTileWidget.updateAll(this)
        }
    }

    private fun askPerm() {
        requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), REQ_PERM)
    }

    // ---------------------------------------------------------------- giao diện

    private fun buildUi(): View {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Palette.BG)
            fitsSystemWindows = true
        }
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), 0)
        }

        // Thanh tiêu đề: ☰  THÁNG MƯỜI 2026  ⌄
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(10))
        }
        val ham = ImageView(this).apply {
            setImageResource(R.drawable.ic_menu)
            setPadding(0, dp(8), dp(18), dp(8))
            contentDescription = "Lịch hiển thị"
            setOnClickListener { calendarsDialog() }
        }
        titleView = TextView(this).apply {
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.06f
            setPadding(0, dp(8), 0, dp(8))
            setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_chevron, 0)
            compoundDrawablePadding = dp(16)
            compoundDrawableTintList = ColorStateList.valueOf(Color.WHITE)
            setOnClickListener { pickDate() }
        }
        header.addView(ham)
        header.addView(titleView)
        main.addView(header)

        content = SwipeFrame(this).apply { onSwipe = { dir -> if (mode != Mode.AGENDA) go(dir) } }
        main.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val full = ViewGroup.LayoutParams.MATCH_PARENT

        // Tuần
        weekGrid = WeekGridLayout(this)
        for (i in 0..6) {
            val cell = DayCell(this)
            cell.setOnClickListener { daySheet(weekStart.plusDays(i.toLong())) }
            cells.add(cell)
            weekGrid.addView(cell)
        }
        mini = MiniMonthView(this).apply { onPick = { jumpTo(it) } }
        weekGrid.addView(mini)
        content.addView(weekGrid, FrameLayout.LayoutParams(full, full))

        // Ngày
        dayRoot = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        dayTitle = TextView(this).apply {
            textSize = 22f
            setPadding(0, dp(2), 0, dp(6))
        }
        allDayBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(6))
        }
        timeline = DayTimelineView(this).apply {
            onEvent = { openEvent(it) }
            onEmpty = { t -> editDialog(null, anchor, t) }
        }
        dayScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(timeline)
        }
        dayRoot.addView(dayTitle)
        dayRoot.addView(allDayBox)
        dayRoot.addView(dayScroll, LinearLayout.LayoutParams(full, 0, 1f))
        content.addView(dayRoot, FrameLayout.LayoutParams(full, full))

        // Tháng
        monthView = MonthGridView(this).apply {
            onPick = { d ->
                anchor = d
                setMode(Mode.DAY)
            }
        }
        content.addView(monthView, FrameLayout.LayoutParams(full, full))

        // Năm
        yearView = YearView(this).apply {
            onPick = { m ->
                val t = LocalDate.now()
                anchor = if (m.year == t.year && m.month == t.month) t else m
                setMode(Mode.MONTH)
            }
        }
        content.addView(yearView, FrameLayout.LayoutParams(full, full))

        // Lịch công tác
        agendaList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(16))
        }
        agendaScroll = ScrollView(this).apply { addView(agendaList) }
        content.addView(agendaScroll, FrameLayout.LayoutParams(full, full))

        // Thanh ứng dụng dưới cùng
        val bar = FrameLayout(this)
        val icons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun barIcon(res: Int, desc: String, action: () -> Unit) {
            val iv = ImageView(this).apply {
                setImageResource(res)
                contentDescription = desc
                scaleType = ImageView.ScaleType.CENTER
                setBackgroundResource(attrRes(android.R.attr.selectableItemBackgroundBorderless))
                setOnClickListener { action() }
            }
            val lp = LinearLayout.LayoutParams(dp(52), dp(52)).apply { setMargins(dp(12), 0, dp(12), 0) }
            icons.addView(iv, lp)
        }
        barIcon(R.drawable.ic_today, "Hôm nay") { hidePanel(); jumpTo(LocalDate.now()) }
        barIcon(R.drawable.ic_add, "Thêm sự kiện") { hidePanel(); editDialog(null, if (mode == Mode.DAY) anchor else LocalDate.now()) }
        barIcon(R.drawable.ic_month, "Kiểu xem") { togglePanel() }
        bar.addView(icons, FrameLayout.LayoutParams(full, dp(60)))
        moreBtn = TextView(this).apply {
            text = "•••"
            textSize = 18f
            letterSpacing = 0.1f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "Thêm tùy chọn"
            setBackgroundResource(attrRes(android.R.attr.selectableItemBackgroundBorderless))
            setOnClickListener { hidePanel(); moreMenu() }
        }
        bar.addView(moreBtn, FrameLayout.LayoutParams(dp(48), dp(60), Gravity.END or Gravity.CENTER_VERTICAL))
        main.addView(bar)

        root.addView(main, FrameLayout.LayoutParams(full, full))
        root.addView(buildPanel(), FrameLayout.LayoutParams(full, full))
        return root
    }

    /** Menu kiểu xem trượt lên phía trên thanh ứng dụng, như Windows Phone. */
    private fun buildPanel(): View {
        overlay = FrameLayout(this).apply {
            visibility = View.GONE
            isClickable = true
            setOnClickListener { hidePanel() }
        }
        sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(PANEL_BG)
            setPadding(dp(24), dp(10), dp(24), dp(10))
            isClickable = true
        }
        val entries = listOf(
            Triple(Mode.AGENDA, "Lịch công tác", R.drawable.ic_v_agenda),
            Triple(Mode.DAY, "Ngày", R.drawable.ic_v_day),
            Triple(Mode.WEEK, "Tuần", R.drawable.ic_v_week),
            Triple(Mode.MONTH, "Tháng", R.drawable.ic_v_month),
            Triple(Mode.YEAR, "Năm", R.drawable.ic_v_year)
        )
        for ((m, label, icon) in entries) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(attrRes(android.R.attr.selectableItemBackground))
                setOnClickListener { setMode(m) }
            }
            val iv = ImageView(this).apply { setImageResource(icon) }
            val tv = TextView(this).apply {
                text = label
                textSize = 21f
                setTextColor(Color.WHITE)
            }
            row.addView(iv, LinearLayout.LayoutParams(dp(28), dp(28)))
            row.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { marginStart = dp(26) })
            modeLabels[m] = tv
            sheet.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)))
        }
        overlay.addView(sheet, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply { bottomMargin = dp(60) })
        return overlay
    }

    private fun togglePanel() {
        if (overlay.visibility == View.VISIBLE) hidePanel() else showPanel()
    }

    private fun showPanel() {
        modeLabels.forEach { (m, tv) -> tv.typeface = if (m == mode) Typeface.DEFAULT_BOLD else Typeface.DEFAULT }
        overlay.visibility = View.VISIBLE
        sheet.translationY = dp(320).toFloat()
        sheet.animate().translationY(0f).setDuration(200).start()
    }

    private fun hidePanel() {
        if (overlay.visibility != View.VISIBLE) return
        sheet.animate().translationY(sheet.height.toFloat()).setDuration(150)
            .withEndAction { overlay.visibility = View.GONE }.start()
    }

    private fun setMode(m: Mode) {
        mode = m
        Prefs.setMode(this, m)
        hidePanel()
        reload(0)
    }

    private fun attrRes(attr: Int): Int {
        val tv = TypedValue()
        theme.resolveAttribute(attr, tv, true)
        return tv.resourceId
    }

    /** Làm sáng màu quá tối để đọc được trên nền đen. */
    private fun readable(c: Int): Int {
        if (c == 0) return accent
        val opaque = c or 0xFF000000.toInt()
        if (Color.luminance(opaque) >= 0.18f) return opaque
        val mix = { ch: Int -> (ch + (255 - ch) * 0.45f).toInt() }
        return Color.rgb(mix(Color.red(opaque)), mix(Color.green(opaque)), mix(Color.blue(opaque)))
    }

    private fun holidays(d: LocalDate): List<String> =
        if (Prefs.builtinHolidays(this)) Holidays.of(d) else emptyList()

    /** Các dòng hiển thị cho một ngày: ngày lễ trước, rồi sự kiện. */
    private fun linesFor(d: LocalDate, withTime: Boolean): List<Line> {
        val lines = ArrayList<Line>()
        holidays(d).forEach { lines.add(Line(null, it, Palette.HOLIDAY)) }
        shown[d]?.forEach { ev ->
            lines.add(Line(if (withTime) timeLabel(ev, d) else null, ev.title, readable(ev.color)))
        }
        return lines
    }

    // ---------------------------------------------------------------- vẽ theo kiểu xem

    private fun reload(dir: Int) {
        val today = LocalDate.now()
        val ref = if (mode == Mode.WEEK) weekStart.plusDays(3) else anchor
        titleView.text = when (mode) {
            Mode.YEAR -> "${anchor.year}"
            Mode.AGENDA -> "LỊCH CÔNG TÁC"
            else -> "THÁNG ${VN.MONTHS[ref.monthValue - 1]} ${ref.year}"
        }
        titleView.setTextColor(accent)

        weekGrid.visibility = vis(mode == Mode.WEEK)
        dayRoot.visibility = vis(mode == Mode.DAY)
        monthView.visibility = vis(mode == Mode.MONTH)
        yearView.visibility = vis(mode == Mode.YEAR)
        agendaScroll.visibility = vis(mode == Mode.AGENDA)

        when (mode) {
            Mode.WEEK -> renderWeek(today, ref)
            Mode.DAY -> renderDay(today)
            Mode.MONTH -> renderMonth(today)
            Mode.YEAR -> yearView.set(anchor.year, today, accent)
            Mode.AGENDA -> renderAgenda(today)
        }

        if (dir != 0) {
            content.translationX = dp(40) * dir.toFloat()
            content.alpha = 0.3f
            content.animate().translationX(0f).alpha(1f).setDuration(220).start()
        }
    }

    private fun vis(b: Boolean) = if (b) View.VISIBLE else View.GONE

    private fun renderWeek(today: LocalDate, ref: LocalDate) {
        shown = Repo.byDay(this, weekStart, weekStart.plusDays(7), Prefs.hidden(this))
        for (i in 0..6) {
            val d = weekStart.plusDays(i.toLong())
            cells[i].bind(d, d == today, d.month != ref.month, linesFor(d, true), accent)
        }
        mini.set(ref, weekStart, today, accent)
    }

    private fun renderDay(today: LocalDate) {
        val d = anchor
        shown = Repo.byDay(this, d, d.plusDays(1), Prefs.hidden(this))
        dayTitle.text = "${VN.dowLong(d)}, ${d.dayOfMonth} tháng ${d.monthValue}"
        dayTitle.setTextColor(if (d == today) accent else Color.WHITE)

        allDayBox.removeAllViews()
        holidays(d).forEach { allDayBox.addView(lineRow(Line(null, it, Palette.HOLIDAY), null)) }
        val timed = ArrayList<Pair<Ev, Int>>()
        for (ev in shown[d] ?: emptyList()) {
            if (ev.allDay) allDayBox.addView(lineRow(Line("cả ngày", ev.title, readable(ev.color)), ev))
            else timed.add(ev to readable(ev.color))
        }
        allDayBox.visibility = vis(allDayBox.childCount > 0)
        timeline.set(d, today, accent, timed)

        if (scrolledDay != d) {
            scrolledDay = d
            val hour = if (d == today) (LocalTime.now().hour - 1).coerceAtLeast(0) else 7
            dayScroll.post { dayScroll.scrollTo(0, timeline.hourPx(hour)) }
        }
    }

    private fun lineRow(line: Line, ev: Ev?): TextView = TextView(this).apply {
        text = line.span()
        textSize = 15f
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
        setPadding(0, dp(4), 0, dp(4))
        if (ev != null) {
            setBackgroundResource(attrRes(android.R.attr.selectableItemBackground))
            setOnClickListener { openEvent(ev) }
        }
    }

    private fun renderMonth(today: LocalDate) {
        val first = mondayOf(anchor.withDayOfMonth(1))
        shown = Repo.byDay(this, first, first.plusDays(42), Prefs.hidden(this))
        val data = HashMap<LocalDate, List<Line>>()
        for (i in 0 until 42) {
            val d = first.plusDays(i.toLong())
            data[d] = linesFor(d, false)
        }
        monthView.set(anchor, today, accent, data)
    }

    private fun renderAgenda(today: LocalDate) {
        val from = anchor
        val to = anchor.plusDays(AGENDA_DAYS)
        shown = Repo.byDay(this, from, to, Prefs.hidden(this))
        agendaList.removeAllViews()
        val zone = ZoneId.systemDefault()
        var any = false
        var d = from
        while (d.isBefore(to)) {
            val hol = holidays(d)
            val evs = shown[d] ?: emptyList()
            if (hol.isNotEmpty() || evs.isNotEmpty()) {
                any = true
                agendaList.addView(TextView(this).apply {
                    text = (if (d == today) "hôm nay · " else "") +
                        "${VN.dowLong(d)}, ${d.dayOfMonth} tháng ${d.monthValue}"
                    textSize = 14f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (d == today) accent else Palette.DIM)
                    setPadding(0, dp(16), 0, dp(6))
                })
                hol.forEach { agendaList.addView(agendaRow(it, "Ngày lễ", Palette.HOLIDAY, null)) }
                for (ev in evs) {
                    val time = if (ev.allDay) "Cả ngày" else {
                        val b = Instant.ofEpochMilli(ev.begin).atZone(zone).toLocalTime().format(VN.HM)
                        val e = Instant.ofEpochMilli(ev.end).atZone(zone).toLocalTime().format(VN.HM)
                        "$b – $e"
                    }
                    val sub = time + if (ev.location.isNotEmpty()) "  ·  ${ev.location}" else ""
                    agendaList.addView(agendaRow(ev.title, sub, readable(ev.color), ev))
                }
            }
            d = d.plusDays(1)
        }
        if (!any) {
            agendaList.addView(TextView(this).apply {
                text = "Không có sự kiện nào trong $AGENDA_DAYS ngày tới.\nBấm + để thêm."
                textSize = 16f
                setTextColor(Palette.DIM)
                setPadding(0, dp(24), 0, 0)
            })
        }
    }

    private fun agendaRow(title: String, sub: String, color: Int, ev: Ev?): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(6), 0, dp(6))
            if (ev != null) {
                setBackgroundResource(attrRes(android.R.attr.selectableItemBackground))
                setOnClickListener { openEvent(ev) }
            }
        }
        val bar = View(this).apply { setBackgroundColor(color) }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        texts.addView(TextView(this).apply {
            text = title
            textSize = 18f
            setTextColor(Color.WHITE)
        })
        texts.addView(TextView(this).apply {
            text = sub
            textSize = 13f
            setTextColor(Palette.DIM)
        })
        row.addView(bar, LinearLayout.LayoutParams(dp(5), ViewGroup.LayoutParams.MATCH_PARENT))
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    /** Giờ hiển thị của sự kiện trong một ngày cụ thể (null nếu cả ngày). */
    private fun timeLabel(ev: Ev, d: LocalDate): String? {
        if (ev.allDay) return null
        val b = Instant.ofEpochMilli(ev.begin).atZone(ZoneId.systemDefault())
        return if (b.toLocalDate() == d) b.toLocalTime().format(VN.HM) else "…"
    }

    private fun go(n: Int) {
        val k = n.toLong()
        anchor = when (mode) {
            Mode.DAY -> anchor.plusDays(k)
            Mode.WEEK -> anchor.plusWeeks(k)
            Mode.MONTH -> anchor.plusMonths(k)
            Mode.YEAR -> anchor.plusYears(k)
            Mode.AGENDA -> anchor
        }
        reload(n)
    }

    private fun jumpTo(d: LocalDate) {
        val samePage = when (mode) {
            Mode.DAY, Mode.AGENDA -> d == anchor
            Mode.WEEK -> mondayOf(d) == weekStart
            Mode.MONTH -> d.year == anchor.year && d.month == anchor.month
            Mode.YEAR -> d.year == anchor.year
        }
        val dir = if (samePage) 0 else Integer.signum(d.compareTo(anchor))
        anchor = d
        reload(dir)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- hộp thoại

    private fun pickDate() {
        hidePanel()
        DatePickerDialog(this, { _, y, m, d -> jumpTo(LocalDate.of(y, m + 1, d)) },
            anchor.year, anchor.monthValue - 1, anchor.dayOfMonth).show()
    }

    private fun daySheet(d: LocalDate) {
        val hol = holidays(d)
        val evs = shown[d] ?: emptyList()
        if (hol.isEmpty() && evs.isEmpty()) {
            editDialog(null, d)
            return
        }
        val items = hol.map { "$it  ·  ngày lễ" } + evs.map { ev ->
            val t = timeLabel(ev, d)
            (t ?: "Cả ngày") + "   " + ev.title + (if (ev.location.isNotEmpty()) "  ·  " + ev.location else "")
        }
        AlertDialog.Builder(this)
            .setTitle("${VN.dowLong(d)}, ${d.dayOfMonth} tháng ${d.monthValue}")
            .setItems(items.toTypedArray()) { _, which ->
                if (which >= hol.size) openEvent(evs[which - hol.size])
            }
            .setPositiveButton("thêm") { _, _ -> editDialog(null, d) }
            .setNeutralButton("xem ngày") { _, _ ->
                anchor = d
                setMode(Mode.DAY)
            }
            .setNegativeButton("đóng", null)
            .show()
    }

    private fun openEvent(ev: Ev) {
        val (s, e) = Repo.span(ev, ZoneId.systemDefault())
        // Sự kiện lặp lại, nhiều ngày hoặc chỉ đọc: mở bằng ứng dụng Lịch của máy để không làm hỏng dữ liệu.
        if (ev.recurring || !ev.canEdit || s != e) viewInSystem(ev) else editDialog(ev, null)
    }

    private fun viewInSystem(ev: Ev) {
        val i = Intent(Intent.ACTION_VIEW, ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, ev.id))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, ev.begin)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, ev.end)
        try {
            startActivity(i)
        } catch (x: ActivityNotFoundException) {
            toast("Không có ứng dụng Lịch để mở sự kiện này")
        }
    }

    private fun pickerRow(): TextView = TextView(this).apply {
        textSize = 16f
        setTextColor(Color.WHITE)
        setPadding(dp(4), dp(12), dp(4), dp(12))
        setBackgroundResource(attrRes(android.R.attr.selectableItemBackground))
    }

    private fun editDialog(ev: Ev?, day: LocalDate?, at: LocalTime? = null) {
        if (!Repo.canWrite(this)) {
            toast("Cần cấp quyền lịch để thêm sự kiện")
            askPerm()
            return
        }
        val act = this
        var cals = Repo.calendars(this).filter { it.writable }
        if (ev == null && cals.isEmpty()) {
            Repo.createLocalCalendar(this)
            cals = Repo.calendars(this).filter { it.writable }
        }
        val zone = ZoneId.systemDefault()
        var date: LocalDate
        var start: LocalTime
        var end: LocalTime
        var allDay: Boolean
        if (ev != null) {
            allDay = ev.allDay
            if (allDay) {
                date = Instant.ofEpochMilli(ev.begin).atZone(ZoneOffset.UTC).toLocalDate()
                start = LocalTime.of(9, 0)
                end = LocalTime.of(10, 0)
            } else {
                val b = Instant.ofEpochMilli(ev.begin).atZone(zone)
                val e = Instant.ofEpochMilli(ev.end).atZone(zone)
                date = b.toLocalDate()
                start = b.toLocalTime().withSecond(0).withNano(0)
                end = e.toLocalTime().withSecond(0).withNano(0)
            }
        } else {
            allDay = false
            date = day ?: LocalDate.now()
            start = at ?: if (date == LocalDate.now())
                LocalTime.now().plusHours(1).withMinute(0).withSecond(0).withNano(0)
            else LocalTime.of(9, 0)
            end = start.plusHours(1)
        }

        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val titleIn = EditText(this).apply {
            hint = "Tiêu đề"
            setText(ev?.title ?: "")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            isSingleLine = true
        }
        val locIn = EditText(this).apply {
            hint = "Địa điểm"
            setText(ev?.location ?: "")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            isSingleLine = true
        }
        val dateRow = pickerRow()
        val allDayBoxIn = CheckBox(this).apply { text = "Cả ngày"; isChecked = allDay }
        val startRow = pickerRow()
        val endRow = pickerRow()

        fun refresh() {
            dateRow.text = "Ngày        ${VN.dowShort(date)}, ${date.format(VN.DMY)}"
            startRow.text = "Bắt đầu    ${start.format(VN.HM)}"
            endRow.text = "Kết thúc   ${end.format(VN.HM)}"
            startRow.visibility = if (allDay) View.GONE else View.VISIBLE
            endRow.visibility = if (allDay) View.GONE else View.VISIBLE
        }
        dateRow.setOnClickListener {
            DatePickerDialog(act, { _, y, m, d -> date = LocalDate.of(y, m + 1, d); refresh() },
                date.year, date.monthValue - 1, date.dayOfMonth).show()
        }
        startRow.setOnClickListener {
            TimePickerDialog(act, { _, h, m ->
                var dur = Duration.between(start, end)
                if (dur.isNegative || dur.isZero) dur = Duration.ofHours(1)
                start = LocalTime.of(h, m)
                end = start.plus(dur)
                refresh()
            }, start.hour, start.minute, true).show()
        }
        endRow.setOnClickListener {
            TimePickerDialog(act, { _, h, m -> end = LocalTime.of(h, m); refresh() },
                end.hour, end.minute, true).show()
        }
        allDayBoxIn.setOnCheckedChangeListener { _, checked -> allDay = checked; refresh() }

        form.addView(titleIn)
        form.addView(locIn)
        form.addView(dateRow)
        form.addView(allDayBoxIn)
        form.addView(startRow)
        form.addView(endRow)

        var spinner: Spinner? = null
        if (ev == null && cals.size > 1) {
            val label = TextView(this).apply {
                text = "Lưu vào lịch"
                setTextColor(Palette.DIM)
                setPadding(dp(4), dp(10), 0, 0)
            }
            val sp = Spinner(this)
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                cals.map { if (it.account.isNotEmpty() && it.account != it.name) "${it.name} · ${it.account}" else it.name })
            val last = cals.indexOfFirst { it.id == Prefs.lastCal(this) }
            if (last >= 0) sp.setSelection(last)
            form.addView(label)
            form.addView(sp)
            spinner = sp
        }
        refresh()

        val builder = AlertDialog.Builder(this)
            .setTitle(if (ev == null) "cuộc hẹn mới" else "sửa cuộc hẹn")
            .setView(ScrollView(this).apply { addView(form) })
            .setPositiveButton("lưu", null)
            .setNegativeButton("hủy", null)
        if (ev != null) builder.setNeutralButton("xóa", null)
        val dlg = builder.create()
        dlg.show()

        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val t = titleIn.text.toString().trim()
            if (t.isEmpty()) {
                titleIn.error = "Nhập tiêu đề"
                return@setOnClickListener
            }
            val b: Long
            val e: Long
            if (allDay) {
                b = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
                e = b + DAY
            } else {
                val s = LocalDateTime.of(date, start).atZone(zone)
                var en = LocalDateTime.of(date, end).atZone(zone)
                if (!en.isAfter(s)) en = en.plusDays(1)
                b = s.toInstant().toEpochMilli()
                e = en.toInstant().toEpochMilli()
            }
            val calId = ev?.calendarId ?: cals.getOrNull(spinner?.selectedItemPosition ?: 0)?.id
            if (calId == null) {
                toast("Không tìm thấy lịch nào để ghi")
                return@setOnClickListener
            }
            if (Repo.save(act, ev?.id, calId, t, locIn.text.toString().trim(), b, e, allDay)) {
                Prefs.setLastCal(act, calId)
                dlg.dismiss()
                if (mode == Mode.AGENDA) reload(0) else jumpTo(date)
                WeekTileWidget.updateAll(act)
                toast(if (ev == null) "Đã thêm vào lịch" else "Đã lưu thay đổi")
            } else {
                toast("Không lưu được vào lịch")
            }
        }
        if (ev != null) {
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                AlertDialog.Builder(act)
                    .setMessage("Xóa \"${ev.title}\" khỏi lịch?")
                    .setPositiveButton("xóa") { _, _ ->
                        if (Repo.delete(act, ev.id)) {
                            dlg.dismiss()
                            reload(0)
                            WeekTileWidget.updateAll(act)
                            toast("Đã xóa")
                        } else toast("Không xóa được")
                    }
                    .setNegativeButton("hủy", null)
                    .show()
            }
        }
    }

    private fun calendarsDialog() {
        hidePanel()
        if (!Repo.hasPerm(this)) {
            askPerm(); return
        }
        val cals = Repo.calendars(this)
        if (cals.isEmpty()) {
            toast("Máy chưa có lịch nào")
            return
        }
        val hidden = Prefs.hidden(this).toMutableSet()
        val names = cals.map { if (it.account.isNotEmpty() && it.account != it.name) "${it.name}\n${it.account}" else it.name }
        val checked = BooleanArray(cals.size) { cals[it].id !in hidden }
        AlertDialog.Builder(this)
            .setTitle("lịch hiển thị")
            .setMultiChoiceItems(names.toTypedArray(), checked) { _, w, on ->
                if (on) hidden.remove(cals[w].id) else hidden.add(cals[w].id)
            }
            .setPositiveButton("xong") { _, _ ->
                Prefs.setHidden(this, hidden)
                reload(0)
                WeekTileWidget.updateAll(this)
            }
            .setNegativeButton("hủy", null)
            .show()
    }

    private fun accentDialog() {
        val box = GridLayout(this).apply {
            columnCount = 5
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        var dlg: AlertDialog? = null
        for (c in Prefs.ACCENTS) {
            val v = View(this)
            v.background = GradientDrawable().apply {
                setColor(c)
                if (c == accent) setStroke(dp(3), Color.WHITE)
            }
            v.setOnClickListener {
                setAccent(c)
                dlg?.dismiss()
            }
            val lp = GridLayout.LayoutParams().apply {
                width = dp(44); height = dp(44)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            box.addView(v, lp)
        }
        dlg = AlertDialog.Builder(this)
            .setTitle("màu nhấn")
            .setView(box)
            .setNegativeButton("đóng", null)
            .show()
    }

    private fun setAccent(c: Int) {
        accent = c
        Prefs.setAccent(this, c)
        reload(0)
        WeekTileWidget.updateAll(this)
    }

    private fun openSystemCalendar() {
        val uri = CalendarContract.CONTENT_URI.buildUpon().appendPath("time")
            .appendPath(System.currentTimeMillis().toString()).build()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (x: ActivityNotFoundException) {
            toast("Không tìm thấy ứng dụng Lịch")
        }
    }

    private fun moreMenu() {
        val pm = PopupMenu(this, moreBtn)
        pm.menu.add(0, 1, 0, "màu nhấn")
        pm.menu.add(0, 2, 1, "lịch hiển thị")
        pm.menu.add(0, 3, 2, "ngày lễ Việt Nam có sẵn").setCheckable(true).setChecked(Prefs.builtinHolidays(this))
        pm.menu.add(0, 4, 3, "mở ứng dụng Lịch của máy")
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        pm.menu.add(0, 5, 4, "phiên bản $ver").isEnabled = false
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> accentDialog()
                2 -> calendarsDialog()
                3 -> {
                    Prefs.setBuiltinHolidays(this, !Prefs.builtinHolidays(this))
                    reload(0)
                    WeekTileWidget.updateAll(this)
                }
                4 -> openSystemCalendar()
            }
            true
        }
        pm.show()
    }
}
