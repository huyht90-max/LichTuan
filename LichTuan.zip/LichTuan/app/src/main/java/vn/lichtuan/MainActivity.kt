package vn.lichtuan

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.CalendarContract
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset

class MainActivity : Activity() {

    private companion object {
        const val REQ_PERM = 7
        const val DAY = 86_400_000L
    }

    private lateinit var grid: WeekGridLayout
    private lateinit var titleView: TextView
    private lateinit var mini: MiniMonthView
    private lateinit var moreBtn: TextView
    private val cells = ArrayList<DayCell>()

    private var weekStart: LocalDate = mondayOf(LocalDate.now())
    private var weekEvents: Map<LocalDate, List<Ev>> = emptyMap()
    private var accent = 0

    // ---------------------------------------------------------------- vòng đời

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        accent = Prefs.accent(this)
        savedInstanceState?.getString("week")?.let { weekStart = LocalDate.parse(it) }
        setContentView(buildUi())
        if (!Repo.canWrite(this)) askPerm()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("week", weekStart.toString())
    }

    override fun onResume() {
        super.onResume()
        reload(0)
        WeekTileWidget.updateAll(this)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            if (!Repo.hasPerm(this)) toast("Chưa có quyền lịch nên chỉ hiện ngày lễ")
            reload(0)
            WeekTileWidget.updateAll(this)
        }
    }

    private fun askPerm() {
        requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), REQ_PERM)
    }

    // ---------------------------------------------------------------- giao diện

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palette.BG)
            fitsSystemWindows = true
            setPadding(dp(16), 0, dp(16), 0)
        }

        // Thanh tiêu đề: ☰  THÁNG MƯỜI 2026  ⌄
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(10))
        }
        val ham = ImageView(this).apply {
            setImageResource(R.drawable.ic_menu)
            setPadding(0, dp(8), dp(18), dp(8))
            contentDescription = "Lịch hiển thị"
            setOnClickListener { calendarsDialog() }
        }
        titleView = TextView(this).apply {
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.06f
            setTextColor(accent)
            setPadding(0, dp(8), 0, dp(8))
            setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_chevron, 0)
            compoundDrawablePadding = dp(16)
            setOnClickListener { pickDate() }
        }
        header.addView(ham)
        header.addView(titleView)
        root.addView(header)

        // Lưới tuần
        grid = WeekGridLayout(this).apply { onSwipe = { go(it) } }
        for (i in 0..6) {
            val cell = DayCell(this)
            cell.setOnClickListener { daySheet(weekStart.plusDays(i.toLong())) }
            cells.add(cell)
            grid.addView(cell)
        }
        mini = MiniMonthView(this).apply { onPick = { jumpTo(it) } }
        grid.addView(mini)
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Thanh ứng dụng dưới cùng
        val bar = FrameLayout(this)
        val icons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun barIcon(res: Int, desc: String, action: () -> Unit) {
            val iv = ImageView(this).apply {
                setImageResource(res)
                contentDescription = desc
                scaleType = ImageView.ScaleType.CENTER
                setBackgroundResource(attrRes(android.R.attr.selectableItemBackgroundBorderless))
                setOnClickListener { action() }
            }
            val lp = LinearLayout.LayoutParams(dp(52), dp(52)).apply { setMargins(dp(12), 0, dp(12), 0) }
            icons.addView(iv, lp)
        }
        barIcon(R.drawable.ic_today, "Hôm nay") { jumpTo(LocalDate.now()) }
        barIcon(R.drawable.ic_add, "Thêm sự kiện") { editDialog(null, LocalDate.now()) }
        barIcon(R.drawable.ic_month, "Sắp tới") { upcomingDialog() }
        bar.addView(icons, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)))
        moreBtn = TextView(this).apply {
            text = "•••"
            textSize = 18f
            letterSpacing = 0.1f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "Thêm tùy chọn"
            setBackgroundResource(attrRes(android.R.attr.selectableItemBackgroundBorderless))
            setOnClickListener { moreMenu() }
        }
        bar.addView(moreBtn, FrameLayout.LayoutParams(dp(48), dp(60), Gravity.END or Gravity.CENTER_VERTICAL))
        root.addView(bar)
        return root
    }

    private fun attrRes(attr: Int): Int {
        val tv = TypedValue()
        theme.resolveAttribute(attr, tv, true)
        return tv.resourceId
    }

    /** Làm sáng màu quá tối để đọc được trên nền đen. */
    private fun readable(c: Int): Int {
        if (c == 0) return accent
        val opaque = c or 0xFF000000.toInt()
        if (Color.luminance(opaque) >= 0.18f) return opaque
        val mix = { ch: Int -> (ch + (255 - ch) * 0.45f).toInt() }
        return Color.rgb(mix(Color.red(opaque)), mix(Color.green(opaque)), mix(Color.blue(opaque)))
    }

    private fun reload(dir: Int) {
        val ref = weekStart.plusDays(3)
        titleView.text = "THÁNG ${VN.MONTHS[ref.monthValue - 1]} ${ref.year}"
        titleView.setTextColor(accent)
        titleView.compoundDrawableTintList = ColorStateList.valueOf(Color.WHITE)

        weekEvents = Repo.byDay(this, weekStart, weekStart.plusDays(7), Prefs.hidden(this))
        val today = LocalDate.now()
        val showHolidays = Prefs.builtinHolidays(this)
        for (i in 0..6) {
            val d = weekStart.plusDays(i.toLong())
            val lines = ArrayList<Line>()
            if (showHolidays) Holidays.of(d).forEach { lines.add(Line(null, it, Palette.HOLIDAY)) }
            weekEvents[d]?.forEach { ev -> lines.add(Line(timeLabel(ev, d), ev.title, readable(ev.color))) }
            cells[i].bind(d, d == today, d.month != ref.month, lines, accent)
        }
        mini.set(ref, weekStart, today, accent)

        if (dir != 0) {
            grid.translationX = dp(40) * dir.toFloat()
            grid.alpha = 0.3f
            grid.animate().translationX(0f).alpha(1f).setDuration(220).start()
        }
    }

    /** Giờ hiển thị của sự kiện trong một ngày cụ thể (null nếu cả ngày). */
    private fun timeLabel(ev: Ev, d: LocalDate): String? {
        if (ev.allDay) return null
        val zone = ZoneId.systemDefault()
        val b = Instant.ofEpochMilli(ev.begin).atZone(zone)
        return if (b.toLocalDate() == d) b.toLocalTime().format(VN.HM) else "…"
    }

    private fun go(n: Int) {
        weekStart = weekStart.plusWeeks(n.toLong())
        reload(n)
    }

    private fun jumpTo(d: LocalDate) {
        val w = mondayOf(d)
        val dir = Integer.signum(w.compareTo(weekStart))
        weekStart = w
        reload(dir)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- hộp thoại

    private fun pickDate() {
        val ref = weekStart.plusDays(3)
        DatePickerDialog(this, { _, y, m, d -> jumpTo(LocalDate.of(y, m + 1, d)) },
            ref.year, ref.monthValue - 1, ref.dayOfMonth).show()
    }

    private fun daySheet(d: LocalDate) {
        val hol = if (Prefs.builtinHolidays(this)) Holidays.of(d) else emptyList()
        val evs = weekEvents[d] ?: emptyList()
        if (hol.isEmpty() && evs.isEmpty()) {
            editDialog(null, d)
            return
        }
        val items = hol.map { "$it  ·  ngày lễ" } + evs.map { ev ->
            val t = timeLabel(ev, d)
            (if (t == null) "Cả ngày" else t) + "   " + ev.title + (if (ev.location.isNotEmpty()) "  ·  " + ev.location else "")
        }
        AlertDialog.Builder(this)
            .setTitle("${VN.dowLong(d)}, ${d.dayOfMonth} tháng ${d.monthValue}")
            .setItems(items.toTypedArray()) { _, which ->
                if (which >= hol.size) openEvent(evs[which - hol.size])
            }
            .setPositiveButton("thêm") { _, _ -> editDialog(null, d) }
            .setNegativeButton("đóng", null)
            .show()
    }

    private fun openEvent(ev: Ev) {
        val (s, e) = Repo.span(ev, ZoneId.systemDefault())
        // Sự kiện lặp lại, nhiều ngày hoặc chỉ đọc: mở bằng ứng dụng Lịch của máy để không làm hỏng dữ liệu.
        if (ev.recurring || !ev.canEdit || s != e) viewInSystem(ev) else editDialog(ev, null)
    }

    private fun viewInSystem(ev: Ev) {
        val i = Intent(Intent.ACTION_VIEW, ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, ev.id))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, ev.begin)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, ev.end)
        try {
            startActivity(i)
        } catch (x: ActivityNotFoundException) {
            toast("Không có ứng dụng Lịch để mở sự kiện này")
        }
    }

    private fun pickerRow(): TextView = TextView(this).apply {
        textSize = 16f
        setTextColor(Color.WHITE)
        setPadding(dp(4), dp(12), dp(4), dp(12))
        setBackgroundResource(attrRes(android.R.attr.selectableItemBackground))
    }

    private fun editDialog(ev: Ev?, day: LocalDate?) {
        if (!Repo.canWrite(this)) {
            toast("Cần cấp quyền lịch để thêm sự kiện")
            askPerm()
            return
        }
        val act = this
        var cals = Repo.calendars(this).filter { it.writable }
        if (ev == null && cals.isEmpty()) {
            Repo.createLocalCalendar(this)
            cals = Repo.calendars(this).filter { it.writable }
        }
        val zone = ZoneId.systemDefault()
        var date: LocalDate
        var start: LocalTime
        var end: LocalTime
        var allDay: Boolean
        if (ev != null) {
            allDay = ev.allDay
            if (allDay) {
                date = Instant.ofEpochMilli(ev.begin).atZone(ZoneOffset.UTC).toLocalDate()
                start = LocalTime.of(9, 0)
                end = LocalTime.of(10, 0)
            } else {
                val b = Instant.ofEpochMilli(ev.begin).atZone(zone)
                val e = Instant.ofEpochMilli(ev.end).atZone(zone)
                date = b.toLocalDate()
                start = b.toLocalTime().withSecond(0).withNano(0)
                end = e.toLocalTime().withSecond(0).withNano(0)
            }
        } else {
            allDay = false
            date = day ?: LocalDate.now()
            start = if (date == LocalDate.now())
                LocalTime.now().plusHours(1).withMinute(0).withSecond(0).withNano(0)
            else LocalTime.of(9, 0)
            end = start.plusHours(1)
        }

        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val titleIn = EditText(this).apply {
            hint = "Tiêu đề"
            setText(ev?.title ?: "")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            isSingleLine = true
        }
        val locIn = EditText(this).apply {
            hint = "Địa điểm"
            setText(ev?.location ?: "")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            isSingleLine = true
        }
        val dateRow = pickerRow()
        val allDayBox = CheckBox(this).apply { text = "Cả ngày"; isChecked = allDay }
        val startRow = pickerRow()
        val endRow = pickerRow()

        fun refresh() {
            dateRow.text = "Ngày        ${VN.dowShort(date)}, ${date.format(VN.DMY)}"
            startRow.text = "Bắt đầu    ${start.format(VN.HM)}"
            endRow.text = "Kết thúc   ${end.format(VN.HM)}"
            startRow.visibility = if (allDay) View.GONE else View.VISIBLE
            endRow.visibility = if (allDay) View.GONE else View.VISIBLE
        }
        dateRow.setOnClickListener {
            DatePickerDialog(act, { _, y, m, d -> date = LocalDate.of(y, m + 1, d); refresh() },
                date.year, date.monthValue - 1, date.dayOfMonth).show()
        }
        startRow.setOnClickListener {
            TimePickerDialog(act, { _, h, m ->
                var dur = Duration.between(start, end)
                if (dur.isNegative || dur.isZero) dur = Duration.ofHours(1)
                start = LocalTime.of(h, m)
                end = start.plus(dur)
                refresh()
            }, start.hour, start.minute, true).show()
        }
        endRow.setOnClickListener {
            TimePickerDialog(act, { _, h, m -> end = LocalTime.of(h, m); refresh() },
                end.hour, end.minute, true).show()
        }
        allDayBox.setOnCheckedChangeListener { _, checked -> allDay = checked; refresh() }

        form.addView(titleIn)
        form.addView(locIn)
        form.addView(dateRow)
        form.addView(allDayBox)
        form.addView(startRow)
        form.addView(endRow)

        var spinner: Spinner? = null
        if (ev == null && cals.size > 1) {
            val label = TextView(this).apply {
                text = "Lưu vào lịch"
                setTextColor(Palette.DIM)
                setPadding(dp(4), dp(10), 0, 0)
            }
            val sp = Spinner(this)
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                cals.map { if (it.account.isNotEmpty() && it.account != it.name) "${it.name} · ${it.account}" else it.name })
            val last = cals.indexOfFirst { it.id == Prefs.lastCal(this) }
            if (last >= 0) sp.setSelection(last)
            form.addView(label)
            form.addView(sp)
            spinner = sp
        }
        refresh()

        val builder = AlertDialog.Builder(this)
            .setTitle(if (ev == null) "cuộc hẹn mới" else "sửa cuộc hẹn")
            .setView(ScrollView(this).apply { addView(form) })
            .setPositiveButton("lưu", null)
            .setNegativeButton("hủy", null)
        if (ev != null) builder.setNeutralButton("xóa", null)
        val dlg = builder.create()
        dlg.show()

        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val t = titleIn.text.toString().trim()
            if (t.isEmpty()) {
                titleIn.error = "Nhập tiêu đề"
                return@setOnClickListener
            }
            val b: Long
            val e: Long
            if (allDay) {
                b = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
                e = b + DAY
            } else {
                val s = LocalDateTime.of(date, start).atZone(zone)
                var en = LocalDateTime.of(date, end).atZone(zone)
                if (!en.isAfter(s)) en = en.plusDays(1)
                b = s.toInstant().toEpochMilli()
                e = en.toInstant().toEpochMilli()
            }
            val calId = ev?.calendarId ?: cals.getOrNull(spinner?.selectedItemPosition ?: 0)?.id
            if (calId == null) {
                toast("Không tìm thấy lịch nào để ghi")
                return@setOnClickListener
            }
            if (Repo.save(act, ev?.id, calId, t, locIn.text.toString().trim(), b, e, allDay)) {
                Prefs.setLastCal(act, calId)
                dlg.dismiss()
                jumpTo(date)
                WeekTileWidget.updateAll(act)
                toast(if (ev == null) "Đã thêm vào lịch" else "Đã lưu thay đổi")
            } else {
                toast("Không lưu được vào lịch")
            }
        }
        if (ev != null) {
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                AlertDialog.Builder(act)
                    .setMessage("Xóa \"${ev.title}\" khỏi lịch?")
                    .setPositiveButton("xóa") { _, _ ->
                        if (Repo.delete(act, ev.id)) {
                            dlg.dismiss()
                            reload(0)
                            WeekTileWidget.updateAll(act)
                            toast("Đã xóa")
                        } else toast("Không xóa được")
                    }
                    .setNegativeButton("hủy", null)
                    .show()
            }
        }
    }

    private fun upcomingDialog() {
        if (!Repo.hasPerm(this)) {
            askPerm(); return
        }
        val zone = ZoneId.systemDefault()
        val now = System.currentTimeMillis()
        val hidden = Prefs.hidden(this)
        val evs = Repo.instances(this, now, now + 30 * DAY)
            .filter { it.calendarId !in hidden && Repo.localEnd(it, zone) > now }
            .sortedBy { Repo.localBegin(it, zone) }
            .take(60)
        if (evs.isEmpty()) {
            AlertDialog.Builder(this).setTitle("sắp tới")
                .setMessage("Không có sự kiện nào trong 30 ngày tới.")
                .setPositiveButton("thêm") { _, _ -> editDialog(null, LocalDate.now()) }
                .setNegativeButton("đóng", null).show()
            return
        }
        val items = evs.map { ev ->
            val b = Instant.ofEpochMilli(Repo.localBegin(ev, zone)).atZone(zone)
            val day = "${VN.dowShort(b.toLocalDate())} ${b.toLocalDate().format(VN.DM)}"
            val time = if (ev.allDay) "cả ngày" else b.toLocalTime().format(VN.HM)
            "$day · $time   ${ev.title}"
        }
        AlertDialog.Builder(this).setTitle("sắp tới")
            .setItems(items.toTypedArray()) { _, w -> openEvent(evs[w]) }
            .setNegativeButton("đóng", null).show()
    }

    private fun calendarsDialog() {
        if (!Repo.hasPerm(this)) {
            askPerm(); return
        }
        val cals = Repo.calendars(this)
        if (cals.isEmpty()) {
            toast("Máy chưa có lịch nào")
            return
        }
        val hidden = Prefs.hidden(this).toMutableSet()
        val names = cals.map { if (it.account.isNotEmpty() && it.account != it.name) "${it.name}\n${it.account}" else it.name }
        val checked = BooleanArray(cals.size) { cals[it].id !in hidden }
        AlertDialog.Builder(this)
            .setTitle("lịch hiển thị")
            .setMultiChoiceItems(names.toTypedArray(), checked) { _, w, on ->
                if (on) hidden.remove(cals[w].id) else hidden.add(cals[w].id)
            }
            .setPositiveButton("xong") { _, _ ->
                Prefs.setHidden(this, hidden)
                reload(0)
                WeekTileWidget.updateAll(this)
            }
            .setNegativeButton("hủy", null)
            .show()
    }

    private fun accentDialog() {
        val box = GridLayout(this).apply {
            columnCount = 5
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        var dlg: AlertDialog? = null
        for (c in Prefs.ACCENTS) {
            val v = View(this)
            v.background = GradientDrawable().apply {
                setColor(c)
                if (c == accent) setStroke(dp(3), Color.WHITE)
            }
            v.setOnClickListener {
                setAccent(c)
                dlg?.dismiss()
            }
            val lp = GridLayout.LayoutParams().apply {
                width = dp(44); height = dp(44)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            box.addView(v, lp)
        }
        dlg = AlertDialog.Builder(this)
            .setTitle("màu nhấn")
            .setView(box)
            .setNegativeButton("đóng", null)
            .show()
    }

    private fun setAccent(c: Int) {
        accent = c
        Prefs.setAccent(this, c)
        reload(0)
        WeekTileWidget.updateAll(this)
    }

    private fun openSystemCalendar() {
        val uri = CalendarContract.CONTENT_URI.buildUpon().appendPath("time")
            .appendPath(System.currentTimeMillis().toString()).build()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (x: ActivityNotFoundException) {
            toast("Không tìm thấy ứng dụng Lịch")
        }
    }

    private fun moreMenu() {
        val pm = PopupMenu(this, moreBtn)
        pm.menu.add(0, 1, 0, "màu nhấn")
        pm.menu.add(0, 2, 1, "lịch hiển thị")
        pm.menu.add(0, 3, 2, "ngày lễ Việt Nam có sẵn").setCheckable(true).setChecked(Prefs.builtinHolidays(this))
        pm.menu.add(0, 4, 3, "mở ứng dụng Lịch của máy")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> accentDialog()
                2 -> calendarsDialog()
                3 -> {
                    Prefs.setBuiltinHolidays(this, !Prefs.builtinHolidays(this))
                    reload(0)
                    WeekTileWidget.updateAll(this)
                }
                4 -> openSystemCalendar()
            }
            true
        }
        pm.show()
    }
}
