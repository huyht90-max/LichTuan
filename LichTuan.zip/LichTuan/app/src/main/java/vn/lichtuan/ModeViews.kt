package vn.lichtuan

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

/** Xem theo tháng: lưới 7 cột x 6 hàng, mỗi ô có số ngày và tên sự kiện. Chạm để mở xem ngày. */
class MonthGridView(ctx: Context) : View(ctx) {
    var onPick: ((LocalDate) -> Unit)? = null
    private var ref: LocalDate = LocalDate.now()
    private var today: LocalDate = LocalDate.now()
    private var accent = Prefs.ACCENTS[0]
    private var data: Map<LocalDate, List<Line>> = emptyMap()
    private val heads = arrayOf("T2", "T3", "T4", "T5", "T6", "T7", "CN")
    private val headH = ctx.dp(24).toFloat()
    private val pad = ctx.dp(3).toFloat()
    private val linePaint = Paint().apply {
        color = Palette.LINE
        strokeWidth = ctx.resources.displayMetrics.density
    }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Palette.DIM; textSize = ctx.sp(12f); typeface = Typeface.DEFAULT_BOLD
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = ctx.sp(15f); typeface = Typeface.DEFAULT_BOLD }
    private val small = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = ctx.sp(10.5f) }
    private val fill = Paint()

    fun set(ref: LocalDate, today: LocalDate, accent: Int, data: Map<LocalDate, List<Line>>) {
        this.ref = ref; this.today = today; this.accent = accent; this.data = data
        invalidate()
    }

    private fun first(): LocalDate = mondayOf(ref.withDayOfMonth(1))

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cw = w / 7f
        val ch = (height - headH) / 6f
        for (i in 0..6) c.drawText(heads[i], cw * i + pad, headH - pad * 2, head)

        val lineH = small.textSize * 1.25f
        val numBlock = pad + num.textSize * 1.15f
        val maxLines = ((ch - numBlock - pad) / lineH).toInt().coerceAtLeast(0)
        var d = first()
        for (r in 0 until 6) {
            for (col in 0..6) {
                val x = cw * col
                val y = headH + ch * r
                val isToday = d == today
                if (isToday) {
                    fill.color = accent
                    c.drawRect(x, y, x + cw, y + ch, fill)
                }
                num.color = when {
                    isToday -> Color.WHITE
                    d.month != ref.month -> Palette.DIM
                    else -> Color.WHITE
                }
                c.drawText(d.dayOfMonth.toString(), x + pad * 1.5f, y + pad + num.textSize, num)
                val items = data[d] ?: emptyList()
                for (i in 0 until minOf(maxLines, items.size)) {
                    val last = i == maxLines - 1 && items.size > maxLines
                    small.color = if (isToday) Color.WHITE else if (last) Palette.DIM else items[i].color
                    val text: CharSequence = if (last) "+${items.size - i}" else
                        TextUtils.ellipsize(items[i].text, small, cw - pad * 2, TextUtils.TruncateAt.END)
                    c.drawText(text, 0, text.length, x + pad, y + numBlock + lineH * (i + 1) - small.descent(), small)
                }
                d = d.plusDays(1)
            }
        }
        for (r in 0..6) {
            val y = headH + ch * r
            c.drawLine(0f, y, w, y, linePaint)
        }
        for (col in 1..6) c.drawLine(cw * col, headH, cw * col, headH + ch * 6, linePaint)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val cw = width / 7f
            val ch = (height - headH) / 6f
            val row = ((e.y - headH) / ch).toInt()
            val col = (e.x / cw).toInt()
            if (e.y >= headH && row in 0..5 && col in 0..6) {
                onPick?.invoke(first().plusDays((row * 7 + col).toLong()))
                performClick()
            }
        }
        return true
    }
}

/** Xem theo ngày: dòng thời gian 24 giờ, sự kiện là các khối màu. Chạm chỗ trống để thêm sự kiện. */
class DayTimelineView(ctx: Context) : View(ctx) {
    var onEvent: ((Ev) -> Unit)? = null
    var onEmpty: ((LocalTime) -> Unit)? = null
    private val hourH = ctx.dp(56).toFloat()
    private val labelW = ctx.dp(52).toFloat()
    private val topPad = ctx.dp(6).toFloat()
    private val gap = ctx.dp(2).toFloat()
    private var day: LocalDate = LocalDate.now()
    private var today: LocalDate = LocalDate.now()
    private var accent = Prefs.ACCENTS[0]
    private var items: List<Pair<Ev, Int>> = emptyList()
    private val hits = ArrayList<Pair<RectF, Ev>>()
    private val linePaint = Paint().apply {
        color = Palette.LINE
        strokeWidth = ctx.resources.displayMetrics.density
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Palette.DIM; textSize = ctx.sp(12f) }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val title = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = ctx.sp(14f) }
    private val sub = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xDDFFFFFF.toInt(); textSize = ctx.sp(12f) }

    private class Block(val ev: Ev, val color: Int, val s: Float, val e: Float) {
        var col = 0
        var cols = 1
    }

    fun hourPx(h: Int): Int = (h * hourH).toInt()

    fun set(day: LocalDate, today: LocalDate, accent: Int, items: List<Pair<Ev, Int>>) {
        this.day = day; this.today = today; this.accent = accent; this.items = items
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), (hourH * 24 + topPad * 2).toInt())
    }

    private fun layoutBlocks(): List<Block> {
        val zone = ZoneId.systemDefault()
        val dayStart = day.atStartOfDay(zone).toInstant().toEpochMilli()
        val blocks = items.map { (ev, color) ->
            val s = ((ev.begin - dayStart) / 60000f).coerceIn(0f, 1410f)
            var e = ((ev.end - dayStart) / 60000f).coerceIn(0f, 1440f)
            if (e - s < 30f) e = s + 30f
            Block(ev, color, s, e)
        }.sortedBy { it.s }
        // Xếp các sự kiện trùng giờ thành nhiều cột cạnh nhau.
        val cluster = ArrayList<Block>()
        val colEnds = ArrayList<Float>()
        var clusterEnd = -1f
        for (b in blocks) {
            if (cluster.isNotEmpty() && b.s >= clusterEnd) {
                cluster.forEach { it.cols = colEnds.size }
                cluster.clear(); colEnds.clear()
            }
            val idx = colEnds.indexOfFirst { it <= b.s }
            if (idx == -1) {
                colEnds.add(b.e); b.col = colEnds.size - 1
            } else {
                colEnds[idx] = b.e; b.col = idx
            }
            cluster.add(b)
            clusterEnd = maxOf(clusterEnd, b.e)
        }
        cluster.forEach { it.cols = colEnds.size }
        return blocks
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        for (h in 0..24) {
            val y = topPad + h * hourH
            c.drawLine(labelW, y, w, y, linePaint)
            if (h < 24) c.drawText("$h:00", 0f, y + label.textSize * 0.4f, label)
        }

        hits.clear()
        val zone = ZoneId.systemDefault()
        val area = w - labelW
        val pad = gap * 2
        for (b in layoutBlocks()) {
            val cw = area / b.cols
            val x0 = labelW + cw * b.col + gap
            val x1 = labelW + cw * (b.col + 1) - gap / 2
            val y0 = topPad + b.s / 60f * hourH + 1
            val y1 = topPad + b.e / 60f * hourH - 1
            val r = RectF(x0, y0, x1, y1)
            fill.color = b.color
            c.drawRect(r, fill)
            hits.add(r to b.ev)
            val tw = x1 - x0 - pad * 2
            if (tw <= 0) continue
            val t = TextUtils.ellipsize(b.ev.title, title, tw, TextUtils.TruncateAt.END)
            val ty = y0 + pad + title.textSize
            c.drawText(t, 0, t.length, x0 + pad, ty, title)
            if (y1 - ty > sub.textSize * 1.4f) {
                val bt = Instant.ofEpochMilli(b.ev.begin).atZone(zone).toLocalTime().format(VN.HM)
                val et = Instant.ofEpochMilli(b.ev.end).atZone(zone).toLocalTime().format(VN.HM)
                val info = "$bt – $et" + if (b.ev.location.isNotEmpty()) "  ${b.ev.location}" else ""
                val s = TextUtils.ellipsize(info, sub, tw, TextUtils.TruncateAt.END)
                c.drawText(s, 0, s.length, x0 + pad, ty + sub.textSize * 1.35f, sub)
            }
        }

        if (day == today) {
            val now = LocalTime.now()
            val y = topPad + (now.hour * 60 + now.minute) / 60f * hourH
            fill.color = accent
            c.drawRect(labelW, y - gap / 2, w, y + gap / 2, fill)
            c.drawCircle(labelW, y, gap * 2.5f, fill)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val hit = hits.lastOrNull { it.first.contains(e.x, e.y) }
            if (hit != null) {
                onEvent?.invoke(hit.second)
            } else if (e.x > labelW) {
                val h = ((e.y - topPad) / hourH).toInt().coerceIn(0, 23)
                onEmpty?.invoke(LocalTime.of(h, 0))
            }
            performClick()
        }
        return true
    }
}

/** Xem theo năm: 12 tháng nhỏ, 3 cột x 4 hàng. Chạm một tháng để mở xem tháng. */
class YearView(ctx: Context) : View(ctx) {
    var onPick: ((LocalDate) -> Unit)? = null
    private var year = LocalDate.now().year
    private var today: LocalDate = LocalDate.now()
    private var accent = Prefs.ACCENTS[0]
    private val pad = ctx.dp(8).toFloat()
    private val name = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = ctx.sp(15f); typeface = Typeface.DEFAULT_BOLD }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val fill = Paint()

    fun set(year: Int, today: LocalDate, accent: Int) {
        this.year = year; this.today = today; this.accent = accent
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val cw = width / 3f
        val ch = height / 4f
        for (m in 0 until 12) {
            val x0 = (m % 3) * cw + pad
            val y0 = (m / 3) * ch + pad
            val iw = cw - pad * 2
            val ih = ch - pad * 2
            val isCur = year == today.year && m + 1 == today.monthValue
            name.color = if (isCur) accent else Color.WHITE
            c.drawText("tháng ${m + 1}", x0, y0 + name.textSize, name)

            val gridTop = y0 + name.textSize * 1.6f
            val rowH = (y0 + ih - gridTop) / 6f
            val colW = iw / 7f
            num.textSize = minOf(rowH * 0.72f, colW * 0.62f)
            val base = (num.descent() + num.ascent()) / 2
            val first = LocalDate.of(year, m + 1, 1)
            val offset = first.dayOfWeek.value - 1
            for (dd in 1..first.lengthOfMonth()) {
                val idx = offset + dd - 1
                val cx = x0 + colW * (idx % 7) + colW / 2
                val cy = gridTop + rowH * (idx / 7) + rowH / 2
                if (isCur && dd == today.dayOfMonth) {
                    fill.color = accent
                    c.drawRect(cx - colW / 2, cy - rowH / 2, cx + colW / 2, cy + rowH / 2, fill)
                    num.color = Color.WHITE
                } else {
                    num.color = if (idx % 7 == 6) Palette.DIM else 0xFFD8D8D8.toInt()
                }
                c.drawText(dd.toString(), cx, cy - base, num)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val col = (e.x / (width / 3f)).toInt()
            val row = (e.y / (height / 4f)).toInt()
            if (col in 0..2 && row in 0..3) {
                onPick?.invoke(LocalDate.of(year, row * 3 + col + 1, 1))
                performClick()
            }
        }
        return true
    }
}
