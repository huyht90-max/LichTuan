package vn.lichtuan

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import android.provider.CalendarContract.Calendars
import android.provider.CalendarContract.Events
import android.provider.CalendarContract.Instances
import android.provider.CalendarContract.Reminders
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.util.TimeZone

/** Một lần xuất hiện của sự kiện (sự kiện lặp lại sẽ có nhiều lần). */
data class Ev(
    val id: Long,
    val title: String,
    val begin: Long,
    val end: Long,
    val allDay: Boolean,
    val color: Int,
    val location: String,
    val calendarId: Long,
    val recurring: Boolean,
    val canEdit: Boolean
)

data class Cal(
    val id: Long,
    val name: String,
    val account: String,
    val color: Int,
    val writable: Boolean,
    val primary: Boolean
)

object Repo {
    private const val DAY = 86_400_000L

    fun hasPerm(c: Context) =
        c.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun canWrite(c: Context) = hasPerm(c) &&
        c.checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun instances(c: Context, start: Long, end: Long): List<Ev> {
        if (!hasPerm(c)) return emptyList()
        val b = Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, start)
        ContentUris.appendId(b, end)
        val proj = arrayOf(
            Instances.EVENT_ID, Instances.TITLE, Instances.BEGIN, Instances.END,
            Instances.ALL_DAY, Instances.DISPLAY_COLOR, Instances.EVENT_LOCATION,
            Instances.CALENDAR_ID, Instances.RRULE, Instances.RDATE,
            Instances.CALENDAR_ACCESS_LEVEL
        )
        val out = ArrayList<Ev>()
        try {
            c.contentResolver.query(b.build(), proj, "${Instances.VISIBLE}=1", null, "${Instances.BEGIN} ASC")
                ?.use { cur ->
                    while (cur.moveToNext()) {
                        out.add(
                            Ev(
                                id = cur.getLong(0),
                                title = cur.getString(1)?.takeIf { it.isNotBlank() } ?: "(Không tiêu đề)",
                                begin = cur.getLong(2),
                                end = cur.getLong(3),
                                allDay = cur.getInt(4) == 1,
                                color = cur.getInt(5),
                                location = cur.getString(6) ?: "",
                                calendarId = cur.getLong(7),
                                recurring = !cur.getString(8).isNullOrEmpty() || !cur.getString(9).isNullOrEmpty(),
                                canEdit = cur.getInt(10) >= Calendars.CAL_ACCESS_CONTRIBUTOR
                            )
                        )
                    }
                }
        } catch (e: Exception) {
            // không đọc được lịch: trả về danh sách rỗng
        }
        return out
    }

    /** Ngày bắt đầu và ngày kết thúc (tính cả ngày cuối) của một sự kiện theo giờ máy. */
    fun span(ev: Ev, zone: ZoneId): Pair<LocalDate, LocalDate> {
        val z: ZoneId = if (ev.allDay) ZoneOffset.UTC else zone
        val s = Instant.ofEpochMilli(ev.begin).atZone(z).toLocalDate()
        val e = Instant.ofEpochMilli(maxOf(ev.end - 1, ev.begin)).atZone(z).toLocalDate()
        return s to e
    }

    /** Thời điểm bắt đầu/kết thúc thực tế theo giờ máy (sự kiện cả ngày được lưu theo UTC). */
    fun localBegin(ev: Ev, zone: ZoneId): Long = if (!ev.allDay) ev.begin else
        Instant.ofEpochMilli(ev.begin).atZone(ZoneOffset.UTC).toLocalDate()
            .atStartOfDay(zone).toInstant().toEpochMilli()

    fun localEnd(ev: Ev, zone: ZoneId): Long = if (!ev.allDay) ev.end else
        Instant.ofEpochMilli(ev.end).atZone(ZoneOffset.UTC).toLocalDate()
            .atStartOfDay(zone).toInstant().toEpochMilli()

    /** Sự kiện xếp theo từng ngày trong khoảng [from, to). */
    fun byDay(c: Context, from: LocalDate, to: LocalDate, hidden: Set<Long>): Map<LocalDate, List<Ev>> {
        val zone = ZoneId.systemDefault()
        val start = from.atStartOfDay(zone).toInstant().toEpochMilli() - DAY
        val end = to.atStartOfDay(zone).toInstant().toEpochMilli() + DAY
        val map = HashMap<LocalDate, MutableList<Ev>>()
        val last = to.minusDays(1)
        for (ev in instances(c, start, end)) {
            if (ev.calendarId in hidden) continue
            val (s0, e0) = span(ev, zone)
            var d: LocalDate = if (s0.isBefore(from)) from else s0
            val e: LocalDate = if (e0.isAfter(last)) last else e0
            while (!d.isAfter(e)) {
                map.getOrPut(d) { ArrayList() }.add(ev)
                d = d.plusDays(1)
            }
        }
        map.values.forEach { list -> list.sortWith(compareBy<Ev>({ !it.allDay }, { it.begin })) }
        return map
    }

    fun calendars(c: Context): List<Cal> {
        if (!hasPerm(c)) return emptyList()
        val proj = arrayOf(
            Calendars._ID, Calendars.CALENDAR_DISPLAY_NAME, Calendars.ACCOUNT_NAME,
            Calendars.CALENDAR_COLOR, Calendars.CALENDAR_ACCESS_LEVEL, Calendars.OWNER_ACCOUNT
        )
        val out = ArrayList<Cal>()
        try {
            c.contentResolver.query(Calendars.CONTENT_URI, proj, null, null, null)?.use { cur ->
                while (cur.moveToNext()) {
                    val account = cur.getString(2) ?: ""
                    out.add(
                        Cal(
                            id = cur.getLong(0),
                            name = cur.getString(1) ?: "Lịch",
                            account = account,
                            color = cur.getInt(3),
                            writable = cur.getInt(4) >= Calendars.CAL_ACCESS_CONTRIBUTOR,
                            primary = account.isNotEmpty() && account == cur.getString(5)
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        return out.sortedWith(compareBy<Cal>({ !it.primary }, { it.name }))
    }

    /** Tạo lịch cục bộ trên máy khi máy chưa có tài khoản lịch nào ghi được. */
    fun createLocalCalendar(c: Context): Long? {
        val name = "Lịch Tuần"
        val uri = Calendars.CONTENT_URI.buildUpon()
            .appendQueryParameter(CalendarContract.CALLER_IS_SYNCADAPTER, "true")
            .appendQueryParameter(Calendars.ACCOUNT_NAME, name)
            .appendQueryParameter(Calendars.ACCOUNT_TYPE, CalendarContract.ACCOUNT_TYPE_LOCAL)
            .build()
        val v = ContentValues().apply {
            put(Calendars.ACCOUNT_NAME, name)
            put(Calendars.ACCOUNT_TYPE, CalendarContract.ACCOUNT_TYPE_LOCAL)
            put(Calendars.NAME, "lichtuan")
            put(Calendars.CALENDAR_DISPLAY_NAME, name)
            put(Calendars.CALENDAR_COLOR, 0xFF0078D7.toInt())
            put(Calendars.CALENDAR_ACCESS_LEVEL, Calendars.CAL_ACCESS_OWNER)
            put(Calendars.OWNER_ACCOUNT, name)
            put(Calendars.VISIBLE, 1)
            put(Calendars.SYNC_EVENTS, 1)
            put(Calendars.CALENDAR_TIME_ZONE, TimeZone.getDefault().id)
        }
        return try {
            c.contentResolver.insert(uri, v)?.let { ContentUris.parseId(it) }
        } catch (e: Exception) {
            null
        }
    }

    /** Thêm mới (id = null) hoặc sửa sự kiện. Trả về true nếu thành công. */
    fun save(
        c: Context, id: Long?, calId: Long, title: String, location: String,
        begin: Long, end: Long, allDay: Boolean
    ): Boolean {
        val v = ContentValues().apply {
            put(Events.TITLE, title)
            put(Events.EVENT_LOCATION, location)
            put(Events.DTSTART, begin)
            put(Events.DTEND, end)
            put(Events.ALL_DAY, if (allDay) 1 else 0)
            put(Events.EVENT_TIMEZONE, if (allDay) "UTC" else TimeZone.getDefault().id)
        }
        return try {
            val cr = c.contentResolver
            if (id == null) {
                v.put(Events.CALENDAR_ID, calId)
                val uri = cr.insert(Events.CONTENT_URI, v) ?: return false
                if (!allDay) {
                    val r = ContentValues().apply {
                        put(Reminders.EVENT_ID, ContentUris.parseId(uri))
                        put(Reminders.MINUTES, 15)
                        put(Reminders.METHOD, Reminders.METHOD_ALERT)
                    }
                    try { cr.insert(Reminders.CONTENT_URI, r) } catch (e: Exception) { }
                }
                true
            } else {
                cr.update(ContentUris.withAppendedId(Events.CONTENT_URI, id), v, null, null) > 0
            }
        } catch (e: Exception) {
            false
        }
    }

    fun delete(c: Context, id: Long): Boolean = try {
        c.contentResolver.delete(ContentUris.withAppendedId(Events.CONTENT_URI, id), null, null) > 0
    } catch (e: Exception) {
        false
    }
}
