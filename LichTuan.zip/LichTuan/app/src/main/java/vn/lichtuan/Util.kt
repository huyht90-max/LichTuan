package vn.lichtuan

import android.content.Context
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter

object VN {
    val MONTHS = arrayOf(
        "MỘT", "HAI", "BA", "TƯ", "NĂM", "SÁU",
        "BẢY", "TÁM", "CHÍN", "MƯỜI", "MƯỜI MỘT", "MƯỜI HAI"
    )
    private val LONG = arrayOf("thứ hai", "thứ ba", "thứ tư", "thứ năm", "thứ sáu", "thứ bảy", "chủ nhật")
    val HM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
    val DM: DateTimeFormatter = DateTimeFormatter.ofPattern("d/M")
    val DMY: DateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    fun dowShort(d: LocalDate): String =
        if (d.dayOfWeek == DayOfWeek.SUNDAY) "CN" else "T${d.dayOfWeek.value + 1}"

    fun dowLong(d: LocalDate): String = LONG[d.dayOfWeek.value - 1]
}

fun mondayOf(d: LocalDate): LocalDate = d.minusDays((d.dayOfWeek.value - 1).toLong())

fun Context.dp(v: Number): Int = (v.toFloat() * resources.displayMetrics.density + 0.5f).toInt()

object Holidays {
    private val FIXED = mapOf(
        "1-1" to "Tết Dương lịch",
        "14-2" to "Lễ Tình nhân",
        "8-3" to "Quốc tế Phụ nữ",
        "26-3" to "Thành lập Đoàn TNCS",
        "30-4" to "Giải phóng miền Nam",
        "1-5" to "Quốc tế Lao động",
        "19-5" to "Sinh nhật Bác Hồ",
        "1-6" to "Quốc tế Thiếu nhi",
        "28-6" to "Ngày Gia đình Việt Nam",
        "27-7" to "Thương binh Liệt sĩ",
        "2-9" to "Quốc khánh",
        "10-10" to "Giải phóng Thủ đô",
        "20-10" to "Ngày phụ nữ Việt Nam",
        "20-11" to "Ngày Nhà giáo Việt Nam",
        "22-12" to "Quân đội Nhân dân",
        "24-12" to "Đêm Giáng sinh",
        "25-12" to "Lễ Giáng sinh",
        "31-12" to "Đêm Giao thừa"
    )

    // Ngày lễ âm lịch đã quy đổi sang dương lịch
    private val LUNAR = mapOf(
        "2025-1-29" to "Tết Nguyên đán", "2025-4-7" to "Giỗ Tổ Hùng Vương",
        "2025-9-6" to "Lễ Vu Lan", "2025-10-6" to "Tết Trung thu",
        "2026-2-16" to "Giao thừa", "2026-2-17" to "Tết Nguyên đán",
        "2026-4-26" to "Giỗ Tổ Hùng Vương", "2026-8-27" to "Lễ Vu Lan",
        "2026-9-25" to "Tết Trung thu",
        "2027-2-5" to "Giao thừa", "2027-2-6" to "Tết Nguyên đán",
        "2027-9-15" to "Tết Trung thu",
        "2028-1-25" to "Giao thừa", "2028-1-26" to "Tết Nguyên đán",
        "2028-10-3" to "Tết Trung thu"
    )

    fun of(d: LocalDate): List<String> {
        val out = ArrayList<String>(2)
        FIXED["${d.dayOfMonth}-${d.monthValue}"]?.let { out.add(it) }
        LUNAR["${d.year}-${d.monthValue}-${d.dayOfMonth}"]?.let { out.add(it) }
        return out
    }
}

object Prefs {
    val ACCENTS: List<Int> = listOf(
        0xFF0078D7, 0xFF1BA1E2, 0xFFA4C400, 0xFF60A917, 0xFF008A00,
        0xFF00ABA9, 0xFF0050EF, 0xFF6A00FF, 0xFFAA00FF, 0xFFF472D0,
        0xFFD80073, 0xFFA20025, 0xFFE51400, 0xFFFA6800, 0xFFF0A30A,
        0xFF825A2C, 0xFF6D8764, 0xFF647687, 0xFF76608A, 0xFF87794E
    ).map { it.toInt() }

    private fun sp(c: Context) = c.getSharedPreferences("lichtuan", Context.MODE_PRIVATE)

    fun accent(c: Context): Int = sp(c).getInt("accent", ACCENTS[0])
    fun setAccent(c: Context, v: Int) = sp(c).edit().putInt("accent", v).apply()

    fun builtinHolidays(c: Context): Boolean = sp(c).getBoolean("holidays", true)
    fun setBuiltinHolidays(c: Context, v: Boolean) = sp(c).edit().putBoolean("holidays", v).apply()

    fun hidden(c: Context): Set<Long> =
        (sp(c).getStringSet("hidden", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()

    fun setHidden(c: Context, v: Set<Long>) =
        sp(c).edit().putStringSet("hidden", v.map { it.toString() }.toSet()).apply()

    fun lastCal(c: Context): Long = sp(c).getLong("lastCal", -1L)
    fun setLastCal(c: Context, v: Long) = sp(c).edit().putLong("lastCal", v).apply()
}
