package vn.lichtuan

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.RippleDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import kotlin.math.abs

object Palette {
    val BG = Color.BLACK
    val LINE = 0xFF2A2A30.toInt()
    val DIM = 0xFF8A8A93.toInt()
    val HOLIDAY = 0xFF3CC35A.toInt()
    val WEEK_ROW = 0xFFC8C8C8.toInt()
    val WEEK_ROW_TEXT = 0xFF222222.toInt()
}

/** Một dòng trong ô ngày: giờ (mờ) + nội dung (màu theo lịch). */
data class Line(val time: String?, val text: String, val color: Int) {
    fun span(): CharSequence {
        val sb = SpannableStringBuilder()
        if (time != null) {
            sb.append(time, ForegroundColorSpan(Palette.DIM), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append("  ")
        }
        val s = sb.length
        sb.append(text)
        sb.setSpan(ForegroundColorSpan(color), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }
}

/** Khung chứa nội dung, vuốt ngang để sang trang trước/sau. */
class SwipeFrame(ctx: Context) : FrameLayout(ctx) {
    var onSwipe: ((Int) -> Unit)? = null
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val minSwipe = ctx.dp(56)
    private var downX = 0f
    private var downY = 0f

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX
                val dy = e.y - downY
                if (onSwipe != null && abs(dx) > slop * 2 && abs(dx) > abs(dy) * 1.5f) return true
            }
        }
        return false
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y
            }
            MotionEvent.ACTION_UP -> {
                val dx = e.x - downX
                if (abs(dx) > minSwipe) onSwipe?.invoke(if (dx < 0) 1 else -1)
            }
        }
        return true
    }
}

/** Lưới 2 cột x 4 hàng có kẻ vạch. */
class WeekGridLayout(ctx: Context) : ViewGroup(ctx) {
    private val paint = Paint().apply {
        color = Palette.LINE
        strokeWidth = ctx.resources.displayMetrics.density
    }

    init {
        setWillNotDraw(false)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        setMeasuredDimension(w, h)
        val cw = w / 2
        val ch = h / 4
        for (i in 0 until childCount) {
            getChildAt(i).measure(
                MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = width / 2
        val ch = height / 4
        for (i in 0 until childCount) {
            val col = i % 2
            val row = i / 2
            getChildAt(i).layout(col * cw, row * ch, col * cw + cw, row * ch + ch)
        }
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        val w = width.toFloat()
        val ch = (height / 4).toFloat()
        val half = paint.strokeWidth / 2
        canvas.drawLine(0f, half, w, half, paint)
        for (r in 1..4) canvas.drawLine(0f, r * ch - half, w, r * ch - half, paint)
        val cx = (width / 2).toFloat()
        canvas.drawLine(cx, 0f, cx, ch * 4, paint)
    }
}

/** Ô một ngày: "24 T7" và các dòng sự kiện. */
class DayCell(ctx: Context) : LinearLayout(ctx) {
    private val head = TextView(ctx)
    private val lines = List(5) { TextView(ctx) }

    init {
        orientation = VERTICAL
        setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(6))
        isClickable = true
        isFocusable = true
        background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null, ColorDrawable(Color.WHITE))
        head.textSize = 17f
        head.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        head.setPadding(0, 0, 0, ctx.dp(2))
        addView(head)
        for (tv in lines) {
            tv.textSize = 13f
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setPadding(0, ctx.dp(2), 0, 0)
            addView(tv)
        }
    }

    fun bind(d: LocalDate, today: Boolean, otherMonth: Boolean, items: List<Line>, accent: Int) {
        head.text = "${d.dayOfMonth} ${VN.dowShort(d)}"
        head.setTextColor(
            when {
                today -> accent
                otherMonth -> Palette.DIM
                else -> Color.WHITE
            }
        )
        val max = lines.size
        val overflow = items.size > max
        val shown = if (overflow) max - 1 else items.size
        for (i in lines.indices) {
            val tv = lines[i]
            when {
                i < shown -> {
                    tv.visibility = View.VISIBLE
                    tv.setTextColor(Color.WHITE)
                    tv.text = items[i].span()
                }
                i == shown && overflow -> {
                    tv.visibility = View.VISIBLE
                    tv.setTextColor(Palette.DIM)
                    tv.text = "+${items.size - shown} nữa"
                }
                else -> tv.visibility = View.GONE
            }
        }
        contentDescription = "${VN.dowLong(d)} ${d.dayOfMonth}, ${items.size} mục"
    }
}

/** Lịch tháng nhỏ ở ô thứ 8, tô sáng tuần đang xem. Chạm một ngày để nhảy tới tuần đó. */
class MiniMonthView(ctx: Context) : View(ctx) {
    var onPick: ((LocalDate) -> Unit)? = null
    private var ref: LocalDate = LocalDate.now()
    private var week: LocalDate = mondayOf(LocalDate.now())
    private var today: LocalDate = LocalDate.now()
    private var accent: Int = Prefs.ACCENTS[0]
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val fill = Paint()
    private val heads = arrayOf("H", "B", "T", "N", "S", "B", "C")
    private var top = 0f
    private var rowH = 0f

    init {
        val p = ctx.dp(6)
        setPadding(p, p, p, p)
        isClickable = true
    }

    fun set(ref: LocalDate, week: LocalDate, today: LocalDate, accent: Int) {
        this.ref = ref; this.week = week; this.today = today; this.accent = accent
        invalidate()
    }

    private fun firstCell(): LocalDate = mondayOf(ref.withDayOfMonth(1))

    override fun onDraw(c: Canvas) {
        val w = (width - paddingLeft - paddingRight).toFloat()
        val h = (height - paddingTop - paddingBottom).toFloat()
        val cw = w / 7
        rowH = minOf(h / 7, context.dp(24).toFloat())
        top = paddingTop + (h - rowH * 7) / 2
        text.textSize = minOf(rowH * 0.62f, cw * 0.62f)
        val base = (text.descent() + text.ascent()) / 2

        text.typeface = Typeface.DEFAULT_BOLD
        text.color = Color.WHITE
        for (i in 0..6) c.drawText(heads[i], paddingLeft + cw * i + cw / 2, top + rowH / 2 - base, text)

        text.typeface = Typeface.DEFAULT
        var d = firstCell()
        for (r in 0 until 6) {
            val y = top + rowH * (r + 1)
            val isWeek = d == week
            if (isWeek) {
                fill.color = Palette.WEEK_ROW
                c.drawRect(paddingLeft.toFloat(), y, paddingLeft + w, y + rowH, fill)
            }
            for (i in 0..6) {
                val x = paddingLeft + cw * i
                val other = d.month != ref.month
                if (d == today) {
                    fill.color = accent
                    c.drawRect(x, y, x + cw, y + rowH, fill)
                    text.color = Color.WHITE
                } else {
                    text.color = when {
                        isWeek -> Palette.WEEK_ROW_TEXT
                        other -> Palette.DIM
                        else -> Color.WHITE
                    }
                }
                c.drawText(d.dayOfMonth.toString(), x + cw / 2, y + rowH / 2 - base, text)
                d = d.plusDays(1)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP && rowH > 0f) {
            val cw = (width - paddingLeft - paddingRight) / 7f
            val row = ((e.y - top) / rowH).toInt() - 1
            val col = ((e.x - paddingLeft) / cw).toInt()
            if (row in 0..5 && col in 0..6) {
                onPick?.invoke(firstCell().plusDays((row * 7 + col).toLong()))
                performClick()
            }
        }
        return true
    }
}
