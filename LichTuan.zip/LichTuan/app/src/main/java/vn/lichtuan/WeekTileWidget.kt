package vn.lichtuan

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

/**
 * Widget kiểu live tile (giống tile Lịch Outlook của Windows Phone):
 * - Mặt 1: sự kiện hôm nay; nếu hôm nay không còn sự kiện thì hiện sự kiện ngày mai.
 * - Mặt 2: ngày hôm nay. Hai mặt luân phiên trượt lên.
 */
class WeekTileWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        updateAll(context)
    }

    override fun onEnabled(context: Context) {
        CalendarChangeJob.schedule(context)
    }

    override fun onDisabled(context: Context) {
        CalendarChangeJob.cancel(context)
        context.getSystemService(AlarmManager::class.java)?.cancel(refreshIntent(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_REFRESH,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED -> updateAll(context)
            else -> super.onReceive(context, intent)
        }
    }

    private class Row(val time: String, val title: String, val sortKey: Long)

    companion object {
        private const val ACTION_REFRESH = "vn.lichtuan.REFRESH"
        private const val DAY = 86_400_000L
        private val ROWS = intArrayOf(R.id.row1, R.id.row2, R.id.row3)
        private val TIMES = intArrayOf(R.id.time1, R.id.time2, R.id.time3)
        private val NAMES = intArrayOf(R.id.name1, R.id.name2, R.id.name3)
        private val MONTH_LOWER = arrayOf(
            "một", "hai", "ba", "tư", "năm", "sáu", "bảy", "tám", "chín", "mười", "mười một", "mười hai"
        )

        fun updateAll(context: Context) {
            val ctx = context.applicationContext
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, WeekTileWidget::class.java))
            if (ids.isEmpty()) return
            val (views, next) = build(ctx)
            for (id in ids) mgr.updateAppWidget(id, views)
            CalendarChangeJob.schedule(ctx)
            // Làm mới khi sự kiện hôm nay kết thúc (để chuyển sang ngày mai) hoặc khi sang ngày mới.
            ctx.getSystemService(AlarmManager::class.java)
                ?.set(AlarmManager.RTC, next + 1000, refreshIntent(ctx))
        }

        private fun refreshIntent(ctx: Context): PendingIntent =
            PendingIntent.getBroadcast(
                ctx, 0,
                Intent(ctx, WeekTileWidget::class.java).setAction(ACTION_REFRESH),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        /** Giờ kiểu Windows Phone tiếng Việt: 3:00 CH, 9:30 SA. */
        private fun vnTime(t: LocalTime): String {
            val h = if (t.hour % 12 == 0) 12 else t.hour % 12
            return "$h:${"%02d".format(t.minute)} ${if (t.hour < 12) "SA" else "CH"}"
        }

        /** Sự kiện còn lại (chưa kết thúc) của một ngày, kèm ngày lễ. */
        private fun rowsFor(ctx: Context, evs: List<Ev>, day: LocalDate, zone: ZoneId, now: Long): List<Row> {
            val dayStart = day.atStartOfDay(zone).toInstant().toEpochMilli()
            val dayEnd = day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
            val rows = ArrayList<Row>()
            if (Prefs.builtinHolidays(ctx)) Holidays.of(day).forEach { rows.add(Row("Cả ngày", it, dayStart - 1)) }
            for (ev in evs) {
                val b = Repo.localBegin(ev, zone)
                val e = Repo.localEnd(ev, zone)
                if (b >= dayEnd || e <= dayStart || e <= now) continue
                val time = if (ev.allDay || b < dayStart) "Cả ngày"
                else vnTime(Instant.ofEpochMilli(b).atZone(zone).toLocalTime())
                rows.add(Row(time, ev.title, if (time == "Cả ngày") dayStart else b))
            }
            return rows.sortedBy { it.sortKey }
        }

        private fun build(ctx: Context): Pair<RemoteViews, Long> {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_tile)
            rv.setInt(R.id.root, "setBackgroundColor", Prefs.accent(ctx))

            val zone = ZoneId.systemDefault()
            val today = LocalDate.now()
            val tomorrow = today.plusDays(1)
            val now = System.currentTimeMillis()
            var next = tomorrow.atStartOfDay(zone).toInstant().toEpochMilli()

            // Mặt 2: ngày hôm nay
            rv.setTextViewText(R.id.bigNum, today.dayOfMonth.toString())
            rv.setTextViewText(R.id.dateLine, "${VN.dowLong(today)}, tháng ${MONTH_LOWER[today.monthValue - 1]}")

            // Mặt 1: sự kiện
            val head: String
            var rows: List<Row> = emptyList()
            val note: String?
            if (!Repo.hasPerm(ctx)) {
                head = "Lịch Tuần"
                note = "Mở app để cấp quyền truy cập lịch"
            } else {
                val hidden = Prefs.hidden(ctx)
                val evs = Repo.instances(ctx, now - DAY, now + 3 * DAY).filter { it.calendarId !in hidden }
                val todayRows = rowsFor(ctx, evs, today, zone, now)
                if (todayRows.isNotEmpty()) {
                    head = "Hôm nay"
                    rows = todayRows
                    note = if (rows.size > ROWS.size) "+${rows.size - ROWS.size} sự kiện khác hôm nay"
                    else "Hôm nay không có sự kiện khác"
                    // Khi sự kiện đầu tiên kết thúc thì làm mới (có thể chuyển sang ngày mai).
                    for (ev in evs) {
                        val e = Repo.localEnd(ev, zone)
                        if (e in (now + 1) until next) next = e
                    }
                } else {
                    val tomorrowRows = rowsFor(ctx, evs, tomorrow, zone, now)
                    if (tomorrowRows.isNotEmpty()) {
                        head = "Ngày mai"
                        rows = tomorrowRows
                        note = if (rows.size > ROWS.size) "+${rows.size - ROWS.size} sự kiện khác ngày mai"
                        else "Hôm nay không còn sự kiện nào"
                    } else {
                        head = "Hôm nay"
                        note = "Không có sự kiện hôm nay và ngày mai"
                    }
                }
            }

            rv.setTextViewText(R.id.head, head)
            for (i in ROWS.indices) {
                if (i < rows.size) {
                    rv.setTextViewText(TIMES[i], rows[i].time)
                    rv.setTextViewText(NAMES[i], rows[i].title)
                    rv.setViewVisibility(ROWS[i], View.VISIBLE)
                } else {
                    rv.setViewVisibility(ROWS[i], View.GONE)
                }
            }
            if (note != null) {
                rv.setTextViewText(R.id.note, note)
                rv.setViewVisibility(R.id.note, View.VISIBLE)
            } else {
                rv.setViewVisibility(R.id.note, View.GONE)
            }

            val open = PendingIntent.getActivity(
                ctx, 1,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.root, open)
            return rv to next
        }
    }
}
