package vn.lichtuan

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Widget kiểu live tile: các sự kiện sắp tới ở trên, ngày hôm nay ở góc dưới.
 * Đặt widget này vào ô tile của launcher (Square Home, Launcher 10...).
 */
class WeekTileWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        updateAll(context)
    }

    override fun onEnabled(context: Context) {
        CalendarChangeJob.schedule(context)
    }

    override fun onDisabled(context: Context) {
        CalendarChangeJob.cancel(context)
        context.getSystemService(AlarmManager::class.java)?.cancel(refreshIntent(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_REFRESH,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED -> updateAll(context)
            else -> super.onReceive(context, intent)
        }
    }

    companion object {
        private const val ACTION_REFRESH = "vn.lichtuan.REFRESH"
        private const val DAY = 86_400_000L
        private val LINE_IDS = intArrayOf(R.id.ev1, R.id.ev2, R.id.ev3, R.id.ev4)

        fun updateAll(context: Context) {
            val ctx = context.applicationContext
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, WeekTileWidget::class.java))
            if (ids.isEmpty()) return
            val (views, next) = build(ctx)
            for (id in ids) mgr.updateAppWidget(id, views)
            CalendarChangeJob.schedule(ctx)
            // Làm mới lại khi sự kiện đầu tiên kết thúc hoặc sang ngày mới.
            ctx.getSystemService(AlarmManager::class.java)
                ?.set(AlarmManager.RTC, next + 1000, refreshIntent(ctx))
        }

        private fun refreshIntent(ctx: Context): PendingIntent =
            PendingIntent.getBroadcast(
                ctx, 0,
                Intent(ctx, WeekTileWidget::class.java).setAction(ACTION_REFRESH),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        private fun build(ctx: Context): Pair<RemoteViews, Long> {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_tile)
            rv.setInt(R.id.root, "setBackgroundColor", Prefs.accent(ctx))

            val zone = ZoneId.systemDefault()
            val today = LocalDate.now()
            rv.setTextViewText(R.id.dayNum, today.dayOfMonth.toString())
            rv.setTextViewText(R.id.dayName, VN.dowLong(today))

            val lines = ArrayList<CharSequence>()
            if (Prefs.builtinHolidays(ctx)) lines.addAll(Holidays.of(today))
            var next = today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()

            if (Repo.hasPerm(ctx)) {
                val now = System.currentTimeMillis()
                val hidden = Prefs.hidden(ctx)
                // Chỉ lấy sự kiện của hôm nay và ngày mai.
                val limit = today.plusDays(2).atStartOfDay(zone).toInstant().toEpochMilli()
                val evs = Repo.instances(ctx, now - DAY, limit + DAY)
                    .filter {
                        it.calendarId !in hidden &&
                            Repo.localEnd(it, zone) > now &&
                            Repo.localBegin(it, zone) < limit
                    }
                    .sortedBy { Repo.localBegin(it, zone) }
                for (ev in evs) {
                    if (lines.size >= LINE_IDS.size) break
                    val b = Instant.ofEpochMilli(Repo.localBegin(ev, zone)).atZone(zone)
                    val d = b.toLocalDate()
                    val dayLabel = when {
                        !d.isAfter(today) -> ""
                        d == today.plusDays(1) -> "Mai "
                        else -> VN.dowShort(d) + " "
                    }
                    val time = if (ev.allDay) "" else b.toLocalTime().format(VN.HM) + "  "
                    lines.add(dayLabel + time + ev.title)
                    val end = Repo.localEnd(ev, zone)
                    if (end < next) next = end
                }
            } else {
                lines.add("Mở Lịch Tuần để cấp quyền")
            }
            if (Prefs.builtinHolidays(ctx)) {
                for (h in Holidays.of(today.plusDays(1))) {
                    if (lines.size < LINE_IDS.size) lines.add("Mai $h")
                }
            }

            for (i in LINE_IDS.indices) {
                if (i < lines.size) {
                    rv.setTextViewText(LINE_IDS[i], lines[i])
                    rv.setViewVisibility(LINE_IDS[i], View.VISIBLE)
                } else {
                    rv.setViewVisibility(LINE_IDS[i], View.GONE)
                }
            }

            val open = PendingIntent.getActivity(
                ctx, 1,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.root, open)
            return rv to next
        }
    }
}
